"use strict";
(self["webpackChunk_jupyterlab_examples_cell_toolbar"] = self["webpackChunk_jupyterlab_examples_cell_toolbar"] || []).push([["style_index_js"],{

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fortawesome/fontawesome-free/css/all.min.css */ "../node_modules/@fortawesome/fontawesome-free/css/all.min.css");



/***/ }),

/***/ "../node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!***************************************************************!*\
  !*** ../node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \***************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "../node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "../node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/

/* stylelint-disable-next-line selector-class-pattern */
.jp-Cell {
  padding: 0;
  margin-bottom: 0.2rem;
}

.jp-Cell .ccb-cellFooterContainer {
   display: flex;
   flex-direction: row; /* Ensure horizontal alignment */
   justify-content: flex-start; /* Move button to the left */
   align-items: center; /* Vertically center the button */
   padding: 0.2rem 0 0.2rem 72px;
  }

  .jp-Cell .ccb-cellFooterBtn {
    color: #fff;
    opacity: 0.7;
    font-size: 1rem;
    font-weight: 500;
    text-transform: uppercase;
    border: none;
    padding: 4px 8px;
    margin: 0.2rem 0;
    text-shadow: 0px 0px 5px rgba(0, 0, 0, 0.15);
    outline: none;
    cursor: pointer;
    user-select: none;  
    margin-left: 0px;
    margin-right: 4px;
  }

  .jp-Placeholder-content .jp-PlaceholderText,
  .jp-Placeholder-content .jp-MoreHorizIcon {
    display: none;
  }

  /* Disable default cell collapsing behavior */
.jp-InputCollapser,
.jp-OutputCollapser,
.jp-Placeholder {
  cursor: auto !important;
  pointer-events: none !important;
}

  /* Add styles for toggle button */
  .jp-Cell .ccb-toggleBtn{
    background: #f0f0f0;
  }

  .jp-Cell .ccb-toggleBtn:hover{
    background-color: #ccc;
  }

  .jp-Cell .ccb-toggleBtn:active{
    background-color: #999;
  }
  
  .jp-Cell .ccb-cellFooterBtn:active {
    background-color: var(--md-blue-600);
    text-shadow: 0px 0px 4px rgba(0, 0, 0, 0.4);
  }
  
  .jp-Cell .ccb-cellFooterBtn:hover {
    background-color: var(--md-blue-500);
    opacity: 1;
    text-shadow: 0px 0px 7px rgba(0, 0, 0, 0.3);
    box-shadow: var(--jp-elevation-z2);
  }
  
  .jp-Cell .ccb-cellFooterBtn {
    background: var(--md-blue-400);
  }
  
  .jp-CodeCell {
    display: flex !important;
    flex-direction: column;
  }
  
  .jp-CodeCell .jp-CellFooter {
    height: auto;
    order: 2;
  }
  
  .jp-Cell .jp-Cell-inputWrapper {
    margin-top: 5px;
  }
  
  .jp-CodeCell .jp-Cell-outputWrapper {
    order: 4;
  }
  
  .explanatory-cell {
    width: 50%;
    float: left;
  }`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC;;AAED,uDAAuD;AACvD;EACE,UAAU;EACV,qBAAqB;AACvB;;AAEA;GACG,aAAa;GACb,mBAAmB,EAAE,gCAAgC;GACrD,2BAA2B,EAAE,4BAA4B;GACzD,mBAAmB,EAAE,iCAAiC;GACtD,6BAA6B;EAC9B;;EAEA;IACE,WAAW;IACX,YAAY;IACZ,eAAe;IACf,gBAAgB;IAChB,yBAAyB;IACzB,YAAY;IACZ,gBAAgB;IAChB,gBAAgB;IAChB,4CAA4C;IAC5C,aAAa;IACb,eAAe;IACf,iBAAiB;IACjB,gBAAgB;IAChB,iBAAiB;EACnB;;EAEA;;IAEE,aAAa;EACf;;EAEA,6CAA6C;AAC/C;;;EAGE,uBAAuB;EACvB,+BAA+B;AACjC;;EAEE,iCAAiC;EACjC;IACE,mBAAmB;EACrB;;EAEA;IACE,sBAAsB;EACxB;;EAEA;IACE,sBAAsB;EACxB;;EAEA;IACE,oCAAoC;IACpC,2CAA2C;EAC7C;;EAEA;IACE,oCAAoC;IACpC,UAAU;IACV,2CAA2C;IAC3C,kCAAkC;EACpC;;EAEA;IACE,8BAA8B;EAChC;;EAEA;IACE,wBAAwB;IACxB,sBAAsB;EACxB;;EAEA;IACE,YAAY;IACZ,QAAQ;EACV;;EAEA;IACE,eAAe;EACjB;;EAEA;IACE,QAAQ;EACV;;EAEA;IACE,UAAU;IACV,WAAW;EACb","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n/* stylelint-disable-next-line selector-class-pattern */\n.jp-Cell {\n  padding: 0;\n  margin-bottom: 0.2rem;\n}\n\n.jp-Cell .ccb-cellFooterContainer {\n   display: flex;\n   flex-direction: row; /* Ensure horizontal alignment */\n   justify-content: flex-start; /* Move button to the left */\n   align-items: center; /* Vertically center the button */\n   padding: 0.2rem 0 0.2rem 72px;\n  }\n\n  .jp-Cell .ccb-cellFooterBtn {\n    color: #fff;\n    opacity: 0.7;\n    font-size: 1rem;\n    font-weight: 500;\n    text-transform: uppercase;\n    border: none;\n    padding: 4px 8px;\n    margin: 0.2rem 0;\n    text-shadow: 0px 0px 5px rgba(0, 0, 0, 0.15);\n    outline: none;\n    cursor: pointer;\n    user-select: none;  \n    margin-left: 0px;\n    margin-right: 4px;\n  }\n\n  .jp-Placeholder-content .jp-PlaceholderText,\n  .jp-Placeholder-content .jp-MoreHorizIcon {\n    display: none;\n  }\n\n  /* Disable default cell collapsing behavior */\n.jp-InputCollapser,\n.jp-OutputCollapser,\n.jp-Placeholder {\n  cursor: auto !important;\n  pointer-events: none !important;\n}\n\n  /* Add styles for toggle button */\n  .jp-Cell .ccb-toggleBtn{\n    background: #f0f0f0;\n  }\n\n  .jp-Cell .ccb-toggleBtn:hover{\n    background-color: #ccc;\n  }\n\n  .jp-Cell .ccb-toggleBtn:active{\n    background-color: #999;\n  }\n  \n  .jp-Cell .ccb-cellFooterBtn:active {\n    background-color: var(--md-blue-600);\n    text-shadow: 0px 0px 4px rgba(0, 0, 0, 0.4);\n  }\n  \n  .jp-Cell .ccb-cellFooterBtn:hover {\n    background-color: var(--md-blue-500);\n    opacity: 1;\n    text-shadow: 0px 0px 7px rgba(0, 0, 0, 0.3);\n    box-shadow: var(--jp-elevation-z2);\n  }\n  \n  .jp-Cell .ccb-cellFooterBtn {\n    background: var(--md-blue-400);\n  }\n  \n  .jp-CodeCell {\n    display: flex !important;\n    flex-direction: column;\n  }\n  \n  .jp-CodeCell .jp-CellFooter {\n    height: auto;\n    order: 2;\n  }\n  \n  .jp-Cell .jp-Cell-inputWrapper {\n    margin-top: 5px;\n  }\n  \n  .jp-CodeCell .jp-Cell-outputWrapper {\n    order: 4;\n  }\n  \n  .explanatory-cell {\n    width: 50%;\n    float: left;\n  }"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "../node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./base.css */ "../node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ })

}]);
//# sourceMappingURL=style_index_js.7867bae04440032b34a9.js.map