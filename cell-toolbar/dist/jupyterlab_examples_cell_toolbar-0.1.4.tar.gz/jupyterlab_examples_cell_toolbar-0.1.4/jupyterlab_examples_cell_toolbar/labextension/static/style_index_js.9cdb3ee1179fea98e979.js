"use strict";
(self["webpackChunk_jupyterlab_examples_cell_toolbar"] = self["webpackChunk_jupyterlab_examples_cell_toolbar"] || []).push([["style_index_js"],{

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fortawesome/fontawesome-free/css/all.min.css */ "../node_modules/@fortawesome/fontawesome-free/css/all.min.css");



/***/ }),

/***/ "../node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!***************************************************************!*\
  !*** ../node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \***************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "../node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "../node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/*
    See the JupyterLab Developer Guide for useful CSS Patterns:

    https://jupyterlab.readthedocs.io/en/stable/developer/css.html
*/

/* stylelint-disable-next-line selector-class-pattern */
.jp-CodeCell.jp-mod-selected .jp-CellFooter,
.jp-CodeCell:hover .jp-CellFooter{
  visibility: visible;
}

.jp-Cell {
  padding: 0;
  margin-bottom: 0.2rem;
}

.jp-Cell .ccb-cellFooterContainer {
   display: flex;
   flex-direction: row; /* Ensure horizontal alignment */
   justify-content: flex-start; /* Move button to the left */
   align-items: center; /* Vertically center the button */
   padding-left: 8px;
  }

  .jp-Cell .ccb-cellFooterBtn {
    color: #fff;
    font-size: 1rem;
    text-transform: uppercase;
    border: none;
    outline: none;
    cursor: pointer;
    user-select: none;
    height: 1.6rem;
    width: 1.6rem;
    margin-right: 5px;
    padding: 0;
  }

  .jp-Cell .ccb-cellFooterBtn:hover {
    background-color: var(--jp-brand-color0);
    opacity: 1;
    text-shadow: 0px 0px 7px rgba(0, 0, 0, 0.3);
  }
  
  .jp-Cell .ccb-cellFooterBtn {
    background-color: var(--jp-brand-color1);
  }
  
  .jp-CodeCell {
    display: flex !important;
    flex-direction: column;
  }
  
  .jp-CodeCell .jp-CellFooter {
    height: auto;
    order: 2;
    margin: 5px 0 10px 0;
    visibility: hidden;
  }
  
  .jp-CodeCell .jp-Cell-outputWrapper {
    order: 4;
  }
`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC;;AAED,uDAAuD;AACvD;;EAEE,mBAAmB;AACrB;;AAEA;EACE,UAAU;EACV,qBAAqB;AACvB;;AAEA;GACG,aAAa;GACb,mBAAmB,EAAE,gCAAgC;GACrD,2BAA2B,EAAE,4BAA4B;GACzD,mBAAmB,EAAE,iCAAiC;GACtD,iBAAiB;EAClB;;EAEA;IACE,WAAW;IACX,eAAe;IACf,yBAAyB;IACzB,YAAY;IACZ,aAAa;IACb,eAAe;IACf,iBAAiB;IACjB,cAAc;IACd,aAAa;IACb,iBAAiB;IACjB,UAAU;EACZ;;EAEA;IACE,wCAAwC;IACxC,UAAU;IACV,2CAA2C;EAC7C;;EAEA;IACE,wCAAwC;EAC1C;;EAEA;IACE,wBAAwB;IACxB,sBAAsB;EACxB;;EAEA;IACE,YAAY;IACZ,QAAQ;IACR,oBAAoB;IACpB,kBAAkB;EACpB;;EAEA;IACE,QAAQ;EACV","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n/* stylelint-disable-next-line selector-class-pattern */\n.jp-CodeCell.jp-mod-selected .jp-CellFooter,\n.jp-CodeCell:hover .jp-CellFooter{\n  visibility: visible;\n}\n\n.jp-Cell {\n  padding: 0;\n  margin-bottom: 0.2rem;\n}\n\n.jp-Cell .ccb-cellFooterContainer {\n   display: flex;\n   flex-direction: row; /* Ensure horizontal alignment */\n   justify-content: flex-start; /* Move button to the left */\n   align-items: center; /* Vertically center the button */\n   padding-left: 8px;\n  }\n\n  .jp-Cell .ccb-cellFooterBtn {\n    color: #fff;\n    font-size: 1rem;\n    text-transform: uppercase;\n    border: none;\n    outline: none;\n    cursor: pointer;\n    user-select: none;\n    height: 1.6rem;\n    width: 1.6rem;\n    margin-right: 5px;\n    padding: 0;\n  }\n\n  .jp-Cell .ccb-cellFooterBtn:hover {\n    background-color: var(--jp-brand-color0);\n    opacity: 1;\n    text-shadow: 0px 0px 7px rgba(0, 0, 0, 0.3);\n  }\n  \n  .jp-Cell .ccb-cellFooterBtn {\n    background-color: var(--jp-brand-color1);\n  }\n  \n  .jp-CodeCell {\n    display: flex !important;\n    flex-direction: column;\n  }\n  \n  .jp-CodeCell .jp-CellFooter {\n    height: auto;\n    order: 2;\n    margin: 5px 0 10px 0;\n    visibility: hidden;\n  }\n  \n  .jp-CodeCell .jp-Cell-outputWrapper {\n    order: 4;\n  }\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "../node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "../node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "../node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "../node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./base.css */ "../node_modules/css-loader/dist/cjs.js!./style/base.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ })

}]);
//# sourceMappingURL=style_index_js.9cdb3ee1179fea98e979.js.map