"use strict";
(self["webpackChunk_jupyterlab_examples_cell_toolbar"] = self["webpackChunk_jupyterlab_examples_cell_toolbar"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CellFooterWithButton: () => (/* binding */ CellFooterWithButton),
/* harmony export */   ContentFactoryWithFooterButton: () => (/* binding */ ContentFactoryWithFooterButton),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/fontawesome-free/css/all.min.css */ "../node_modules/@fortawesome/fontawesome-free/css/all.min.css");
// Import necessary dependencies from React, JupyterLab, and other modules





// Define CSS classes used in the cell footer.
const CSS_CLASSES = {
    CELL_FOOTER: 'jp-CellFooter',
    CELL_FOOTER_DIV: 'ccb-cellFooterContainer',
    CELL_FOOTER_BUTTON: 'ccb-cellFooterBtn',
    CUSTOM_OUTPUT_AREA: 'custom-output-area',
};
// Define command constants
const COMMANDS = {
    RUN_SELECTED_CODECELL: 'run-selected-codecell',
    INTERRUPT_KERNEL: 'notebook:interrupt-kernel',
    CLEAR_SELECTED_OUTPUT: 'clear-output-cell',
};
// Function to activate custom commands
function activateCommands(app, tracker) {
    // Output a message to the console to indicate activation
    console.log('JupyterLab extension celltool_bar is activated!');
    // Wait for the app to be restored before proceeding
    Promise.all([app.restored]).then(([params]) => {
        const { commands, shell } = app;
        // Function to get the current NotebookPanel
        function getCurrent(args) {
            const widget = tracker.currentWidget;
            const activate = args.activate !== false;
            if (activate && widget) {
                shell.activateById(widget.id);
            }
            return widget;
        }
        /**
        * Function to check if the command should be enabled.
        * It checks if there is a current notebook widget and if it matches the app's current widget.
        * If both conditions are met, the command is considered enabled.
        */
        function isEnabled() {
            return (tracker.currentWidget !== null &&
                tracker.currentWidget === app.shell.currentWidget);
        }
        // Define a command to run the code in the current cell
        commands.addCommand(COMMANDS.RUN_SELECTED_CODECELL, {
            label: 'Run Cell',
            execute: args => {
                const current = getCurrent(args);
                if (current) {
                    const { context, content } = current;
                    _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.run(content, context.sessionContext);
                }
            },
            isEnabled
        });
        commands.addCommand(COMMANDS.CLEAR_SELECTED_OUTPUT, {
            label: 'Clear Output',
            execute: args => {
                const current = getCurrent(args);
                if (current) {
                    const { content } = current;
                    _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.clearOutputs(content);
                }
            },
            isEnabled
        });
    });
    return Promise.resolve();
}
/**
 * Extend the default implementation of an `IContentFactory`.
 */
class ContentFactoryWithFooterButton extends _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookPanel.ContentFactory {
    constructor(commands, options) {
        super(options);
        this.commands = commands;
    }
    /**
     * Create a new cell header for the parent widget.
     */
    createCellFooter() {
        return new CellFooterWithButton(this.commands);
    }
}
/**
 * Extend the default implementation of a cell footer with custom buttons.
 */
class CellFooterWithButton extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(commands) {
        super();
        this.RUN_ICON = 'fa-solid fa-circle-play';
        this.CLEAR_ICON = 'fa-solid fa-ban';
        this.STOP_ICON = 'fa-solid fa-stop';
        this.addClass(CSS_CLASSES.CELL_FOOTER);
        this.commands = commands;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: CSS_CLASSES.CELL_FOOTER_DIV }, react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
            className: 'jp-Placeholder-prompt jp-InputPrompt',
        }), react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
            className: CSS_CLASSES.CELL_FOOTER_BUTTON,
            title: "Run this cell",
            onClick: () => {
                this.commands.execute(COMMANDS.RUN_SELECTED_CODECELL);
            },
        }, react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: this.RUN_ICON })), react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
            className: CSS_CLASSES.CELL_FOOTER_BUTTON,
            title: "Interrupt Execution",
            onClick: () => {
                this.commands.execute(COMMANDS.INTERRUPT_KERNEL);
            },
        }, react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: this.STOP_ICON })), react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
            className: CSS_CLASSES.CELL_FOOTER_BUTTON,
            title: "Clear cell output",
            onClick: () => {
                this.commands.execute(COMMANDS.CLEAR_SELECTED_OUTPUT);
            },
        }, react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: this.CLEAR_ICON })));
    }
}
/**
 * Define a JupyterLab extension to add footer buttons to code cells.
 */
const footerButtonExtension = {
    id: 'jupyterlab-aaVisualPolish',
    autoStart: true,
    activate: activateCommands,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.INotebookTracker]
};
/**
 * Define a JupyterLab extension to override the default notebook cell factory.
 */
const cellFactory = {
    id: 'jupyterlab-aaVisualPolish:factory',
    provides: _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookPanel.IContentFactory,
    requires: [_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3__.IEditorServices],
    autoStart: true,
    activate: (app, editorServices) => {
        const { commands } = app;
        const editorFactory = editorServices.factoryService.newInlineEditor;
        return new ContentFactoryWithFooterButton(commands, { editorFactory });
    }
};
/**
 * Export this plugins as default.
 */
const plugins = [
    footerButtonExtension,
    cellFactory
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugins);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.957c3c0fc4d4dc8bab26.js.map